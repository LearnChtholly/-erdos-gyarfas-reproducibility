# Erdős–Gyárfás cubic-density reproducibility package v0.1

This repository is the **code/data/certificate companion** to the separate manuscript
`Additive Cubic-Density Constraints on Minimal Counterexamples to the Erdős–Gyárfás Conjecture`.
The manuscript itself is intentionally not included here.

## Status

**Research draft / strong computer-assisted theorem candidates; not externally reviewed.**
No priority claim is made, and these results do **not** resolve the Erdős–Gyárfás conjecture.

The current candidate statements are:

- Universal additive +8: for a vertex-minimal, then edge-minimal counterexample, if
  `a = |V_3(G)|` and `b = |V_{>=4}(G)|`, then `a >= 2b + 8`.
- Stronger T10 range: if `b >= 14`, then `a >= 2b + 10`.

## Requirements

- Python 3
- NetworkX
- a C++17 compiler (`g++` tested)

## Layout

- `universal8/small_b/` — complete `b=4,...,7` atlas regeneration, global component searches,
  and the `d=4,z=2` half-edge enumeration.
- `universal8/b8plus8/` — the new `b=8` proof-critical package.
- `universal8/p8/` — the `b=9,10` finite package and the `b>=11` fixed-defect dependency.
- `t10/` — the `b>=14 => a>=2b+10` endpoint-budget proof data and independent verifiers.
- `t10/legacy_v1_0/` — the older exact-cover/DAG route retained as a supplementary independent check.

## Quick reproduction

### Universal +8, b=4,...,7

```bash
cd universal8/small_b
bash reproduce_small_b.sh
```

### Universal +8, b=8

```bash
cd universal8/b8plus8
bash reproduce_quick.sh
```

The slower supplementary exact-quota checks are:

```bash
bash reproduce_supplementary.sh
```

### Universal +8, b=9,10

```bash
cd universal8/p8
bash reproduce_p8.sh
```

### T10, b>=14 strengthening

```bash
cd t10
bash reproduce_v1_1.sh
```

The T10 full run is substantially slower than the small-order modules.

## Proof boundary

The programs do not establish the theorem from an unconstrained graph search.  The manuscript first
reduces a hypothetical minimal counterexample to finite suppression-core/lift families.  The code
certifies the finite statements used after that reduction.  In the endpoint-budget modules the local
families are deliberately *relaxations* of true lifts, so the critical implication is

`true component => enumerated locally admissible component`.

This human/computation interface should receive independent mathematical review.

## Integrity

`SHA256SUMS.txt` records hashes of every file in this package (except the hash file itself).
A public release should be tagged/frozen and the Git commit hash should be recorded in the paper.
